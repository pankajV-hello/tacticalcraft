# TacticalCraft — Claude Code Project Guide

## What this is
TacticalCraft is a hybrid sandbox FPS game built in **Godot 4.x** (GDScript).
It combines Minecraft-style voxel building with Call of Duty-style tactical FPS combat.
Domain: tacticalcraft.games | Owner: Pankaj Verma | Location: Melbourne, AU

## Tech stack
| Layer | Tool | Notes |
|---|---|---|
| Game engine | Godot 4.3+ | GDScript, not C# |
| Voxel system | Custom chunked voxel (src/world/) | Chunk size: 16x16x16 |
| Multiplayer | Nakama (self-hosted) + Godot HTTP/WebSocket | REST auth + WS realtime |
| Backend infra | Hetzner VPS (Ubuntu 24.04) | Sydney region |
| Database | PostgreSQL + Redis (via Nakama) | |
| Payments | Stripe API | Season pass + cosmetics |
| Auth | Nakama email/password + Steam SSO | |

## Project structure
```
tacticalcraft/
├── CLAUDE.md               ← you are here
├── project.godot
├── src/
│   ├── world/
│   │   ├── VoxelWorld.gd       # World manager — owns all chunks
│   │   ├── Chunk.gd            # 16x16x16 voxel chunk
│   │   ├── WorldGenerator.gd   # Procedural terrain (noise-based)
│   │   └── BlockRegistry.gd    # All block types and properties
│   ├── player/
│   │   ├── Player.gd           # FPS controller (CharacterBody3D)
│   │   ├── PlayerCamera.gd     # Mouse look, FOV, bobbing
│   │   ├── BuildController.gd  # Ray-cast block place/break
│   │   └── PlayerStats.gd      # Health, stamina, class attributes
│   ├── weapons/
│   │   ├── WeaponManager.gd    # Equip/switch weapons
│   │   ├── BaseWeapon.gd       # Abstract weapon class
│   │   ├── AssaultRifle.gd     # Weapon implementation
│   │   └── Projectile.gd       # Bullet physics + damage
│   ├── network/
│   │   ├── NakamaClient.gd     # Nakama REST + WebSocket wrapper
│   │   ├── GameSession.gd      # Match state, player sync
│   │   └── RPCHandler.gd       # Godot RPC definitions
│   ├── enemies/
│   │   ├── EnemyBase.gd        # Base enemy AI (NavigationAgent3D)
│   │   └── WaveManager.gd      # AI invasion wave spawner
│   ├── ui/
│   │   ├── HUD.gd              # In-game heads-up display
│   │   ├── MainMenu.gd         # Main menu + matchmaking
│   │   └── BuildMenu.gd        # Block selection radial menu
│   └── ai/
│       └── ClaudeEventGen.gd   # Claude API world event generator
├── assets/
│   ├── scenes/                 # .tscn scene files
│   └── scripts/                # Autoload singletons
└── addons/
    └── voxel_core/             # Godot Voxel plugin (zylann)
```

## Coding rules (always follow)
1. GDScript only — no C#
2. All nodes typed: `var player: Player`, not `var player`
3. Signals over direct calls for cross-node communication
4. Use `@export` for inspector-configurable values
5. Max function length: 40 lines. Extract if longer.
6. Every public function has a one-line docstring
7. All network calls are async with timeout handling
8. Block IDs are enums, never raw integers in game logic

## Key constants
```gdscript
const CHUNK_SIZE = 16          # voxels per chunk side
const WORLD_HEIGHT = 128       # max world height in voxels
const VOXEL_SIZE = 1.0         # metres per voxel
const MAX_PLAYERS = 32         # per match
const NAKAMA_URL = "http://localhost:7350"  # local dev
const CLAUDE_API_URL = "https://api.anthropic.com/v1/messages"
```

## Running locally
```bash
# 1. Install Godot 4.3+
# 2. Install Nakama locally (Docker):
docker run -d --name nakama \
  -p 7349:7349 -p 7350:7350 -p 7351:7351 \
  heroiclabs/nakama --name tacticalcraft

# 3. Open project in Godot Editor
# 4. Install Godot Voxel addon from Asset Library
# 5. Run — default scene: assets/scenes/MainMenu.tscn
```

## Current phase: Phase 1 (prototype)
Focus: Get the core loop working — voxel world + FPS movement + basic multiplayer
Do NOT build: Clan system, Battle Pass, cosmetics, mobile — that's Phase 2+

## When Claude Code asks what to work on next:
Priority order: VoxelWorld → Player → WeaponManager → NakamaClient → WaveManager → HUD
