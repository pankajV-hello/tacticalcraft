## BaseWeapon.gd
## Abstract base for all weapons. Extend this for each gun type.
## Attach to: Node3D child of WeaponManager
extends Node3D

signal fired(origin: Vector3, direction: Vector3)
signal reloaded()
signal ammo_changed(current: int, reserve: int)

## Override these in each weapon subclass
@export var weapon_name: String        = "Unknown Weapon"
@export var damage: float              = 20.0
@export var fire_rate: float           = 0.1     # seconds between shots
@export var magazine_size: int         = 30
@export var reserve_ammo: int          = 90
@export var reload_time: float         = 2.0
@export var bullet_speed: float        = 200.0
@export var max_range: float           = 150.0
@export var spread: float              = 0.02    # aim spread in radians
@export var is_automatic: bool         = true

@onready var anim_player: AnimationPlayer = $AnimationPlayer
@onready var muzzle_flash: GPUParticles3D = $MuzzleFlash
@onready var shoot_sfx: AudioStreamPlayer3D = $ShootSFX
@onready var reload_sfx: AudioStreamPlayer3D = $ReloadSFX

var current_ammo: int
var _fire_timer: float  = 0.0
var _is_reloading: bool = false
var _camera: Camera3D

func _ready() -> void:
	current_ammo = magazine_size
	_camera = get_tree().get_first_node_in_group("player_camera")

func _process(delta: float) -> void:
	if not _owner_is_local_player():
		return
	_fire_timer = max(0.0, _fire_timer - delta)
	if _is_reloading:
		return
	if current_ammo == 0 and Input.is_action_just_pressed("reload"):
		_start_reload()
		return
	var can_fire := Input.is_action_pressed("fire") if is_automatic else Input.is_action_just_pressed("fire")
	if can_fire and _fire_timer == 0.0 and current_ammo > 0:
		_fire()

func _fire() -> void:
	_fire_timer = fire_rate
	current_ammo -= 1
	ammo_changed.emit(current_ammo, reserve_ammo)
	var direction := _get_fire_direction()
	_apply_spread(direction)
	_do_hitscan(direction)
	muzzle_flash.restart()
	shoot_sfx.play()
	anim_player.play("fire")
	fired.emit(_camera.global_position, direction)
	if current_ammo == 0:
		_start_reload()

func _get_fire_direction() -> Vector3:
	return -_camera.global_transform.basis.z

func _apply_spread(direction: Vector3) -> void:
	direction.x += randf_range(-spread, spread)
	direction.y += randf_range(-spread, spread)
	direction = direction.normalized()

func _do_hitscan(direction: Vector3) -> void:
	var space := get_viewport().get_world_3d().direct_space_state
	var origin := _camera.global_position
	var query  := PhysicsRayQueryParameters3D.create(origin, origin + direction * max_range)
	query.exclude = [get_parent().get_parent().get_rid()]  # exclude self
	var hit    := space.intersect_ray(query)
	if hit.is_empty():
		return
	var collider := hit.collider
	# Block destruction
	if collider.is_in_group("voxel_world"):
		var world_pos := Vector3i(hit.position - hit.normal * 0.5)
		var world: Node = get_tree().get_first_node_in_group("voxel_world")
		var block_id: int = world.get_block(world_pos)
		var data: BlockRegistry.BlockData = BlockRegistry.get_block(block_id)
		if damage >= data.blast_resist * 2.0:
			world.set_block.rpc(world_pos, BlockRegistry.BlockID.AIR, multiplayer.get_unique_id())
	# Player hit
	elif collider.is_in_group("player"):
		collider.take_damage.rpc_id(collider.get_multiplayer_authority(), damage, multiplayer.get_unique_id())
	# Enemy hit
	elif collider.is_in_group("enemy"):
		collider.take_damage(damage)

func _start_reload() -> void:
	if reserve_ammo <= 0 or _is_reloading:
		return
	_is_reloading = true
	reload_sfx.play()
	anim_player.play("reload")
	await get_tree().create_timer(reload_time).timeout
	var needed := magazine_size - current_ammo
	var taken  := min(needed, reserve_ammo)
	current_ammo += taken
	reserve_ammo -= taken
	_is_reloading = false
	reloaded.emit()
	ammo_changed.emit(current_ammo, reserve_ammo)

func _owner_is_local_player() -> bool:
	return get_parent().get_parent().is_multiplayer_authority()
