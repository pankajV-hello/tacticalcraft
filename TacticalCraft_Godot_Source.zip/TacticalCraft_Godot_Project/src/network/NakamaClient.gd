## NakamaClient.gd
## Nakama game server integration — auth, matchmaking, realtime socket
## Autoload singleton — add as "NakamaClient" in Project > Autoloads
extends Node

signal authenticated(session_token: String, user_id: String)
signal auth_failed(error: String)
signal match_joined(match_id: String)
signal match_data_received(op_code: int, data: Dictionary)
signal player_joined(presence: Dictionary)
signal player_left(presence: Dictionary)

const NAKAMA_URL: String    = "http://localhost:7350"
const NAKAMA_WS_URL: String = "ws://localhost:7350"
const SERVER_KEY: String    = "defaultkey"   # change in production
const TIMEOUT_SEC: float    = 10.0

var session_token: String  = ""
var user_id: String        = ""
var _match_id: String      = ""
var _ws: WebSocketPeer     = WebSocketPeer.new()
var _ws_connected: bool    = false
var _http: HTTPRequest

func _ready() -> void:
	_http = HTTPRequest.new()
	add_child(_http)

func _process(_delta: float) -> void:
	if _ws_connected:
		_ws.poll()
		var state := _ws.get_ready_state()
		if state == WebSocketPeer.STATE_OPEN:
			while _ws.get_available_packet_count() > 0:
				_on_ws_packet(_ws.get_packet())
		elif state == WebSocketPeer.STATE_CLOSED:
			_ws_connected = false
			push_warning("NakamaClient: WebSocket disconnected")

## Authenticate with email + password. Creates account if new.
func authenticate_email(email: String, password: String, display_name: String = "") -> void:
	var url := NAKAMA_URL + "/v2/account/authenticate/email?create=true"
	if display_name != "":
		url += "&username=" + display_name.uri_encode()
	var auth := "Basic " + Marshalls.utf8_to_base64(SERVER_KEY + ":")
	var body := JSON.stringify({"email": email, "password": password})
	var err := await _post(url, body, {"Authorization": auth})
	if err.has("token"):
		session_token = err["token"]
		user_id       = err.get("account_id", "")
		authenticated.emit(session_token, user_id)
		await _connect_socket()
	else:
		auth_failed.emit(err.get("message", "Authentication failed"))

## Quick device auth for anonymous / guest play
func authenticate_device(device_id: String) -> void:
	var url  := NAKAMA_URL + "/v2/account/authenticate/device?create=true"
	var auth := "Basic " + Marshalls.utf8_to_base64(SERVER_KEY + ":")
	var body := JSON.stringify({"id": device_id})
	var err  := await _post(url, body, {"Authorization": auth})
	if err.has("token"):
		session_token = err["token"]
		authenticated.emit(session_token, "")
		await _connect_socket()
	else:
		auth_failed.emit("Device auth failed")

## Create or join a match by name
func join_or_create_match(match_name: String) -> void:
	var msg := {"match_join": {"name": match_name}}
	_ws_send(msg)

## Send game state update to all match participants
func send_match_data(op_code: int, data: Dictionary) -> void:
	if _match_id == "":
		push_error("NakamaClient: Not in a match")
		return
	var msg := {
		"match_data_send": {
			"match_id": _match_id,
			"op_code": op_code,
			"data": Marshalls.utf8_to_base64(JSON.stringify(data))
		}
	}
	_ws_send(msg)

func _connect_socket() -> void:
	var ws_url := NAKAMA_WS_URL + "/ws?token=" + session_token.uri_encode() + "&format=json"
	_ws.connect_to_url(ws_url)
	# Wait for connection
	var timeout := Time.get_ticks_msec() + int(TIMEOUT_SEC * 1000)
	while _ws.get_ready_state() != WebSocketPeer.STATE_OPEN:
		_ws.poll()
		await get_tree().process_frame
		if Time.get_ticks_msec() > timeout:
			push_error("NakamaClient: Socket connection timed out")
			return
	_ws_connected = true

func _on_ws_packet(packet: PackedByteArray) -> void:
	var text := packet.get_string_from_utf8()
	var msg: Dictionary = JSON.parse_string(text)
	if msg == null:
		return
	if msg.has("match_presence_event"):
		var ev: Dictionary = msg["match_presence_event"]
		for presence in ev.get("joins", []):
			player_joined.emit(presence)
		for presence in ev.get("leaves", []):
			player_left.emit(presence)
	elif msg.has("match_data"):
		var d: Dictionary = msg["match_data"]
		var raw: String   = Marshalls.base64_to_utf8(d.get("data", ""))
		var data: Dictionary = JSON.parse_string(raw) if raw != "" else {}
		match_data_received.emit(d.get("op_code", 0), data)
	elif msg.has("match"):
		_match_id = msg["match"].get("match_id", "")
		match_joined.emit(_match_id)

func _ws_send(msg: Dictionary) -> void:
	if not _ws_connected:
		push_error("NakamaClient: Socket not connected")
		return
	_ws.send_text(JSON.stringify(msg))

func _post(url: String, body: String, extra_headers: Dictionary = {}) -> Dictionary:
	var headers := ["Content-Type: application/json"]
	for k in extra_headers:
		headers.append("%s: %s" % [k, extra_headers[k]])
	_http.request(url, headers, HTTPClient.METHOD_POST, body)
	var result: Array = await _http.request_completed
	var response_code: int = result[1]
	var response_body: String = result[3].get_string_from_utf8()
	if response_code != 200:
		push_warning("NakamaClient: HTTP %d — %s" % [response_code, response_body])
	return JSON.parse_string(response_body) if response_body != "" else {}
