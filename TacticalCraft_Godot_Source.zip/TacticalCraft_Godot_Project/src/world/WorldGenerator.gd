## WorldGenerator.gd
## Procedural terrain using layered FastNoiseLite
## Biomes: Plains, Desert, Forest, Underground Cave systems
extends RefCounted

var seed: int = 12345

var _terrain_noise: FastNoiseLite
var _cave_noise: FastNoiseLite
var _biome_noise: FastNoiseLite

enum Biome { PLAINS, DESERT, FOREST, TUNDRA }

func _init() -> void:
	_terrain_noise = FastNoiseLite.new()
	_terrain_noise.noise_type = FastNoiseLite.TYPE_PERLIN
	_terrain_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_terrain_noise.fractal_octaves = 5
	_terrain_noise.frequency = 0.003

	_cave_noise = FastNoiseLite.new()
	_cave_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
	_cave_noise.frequency = 0.04

	_biome_noise = FastNoiseLite.new()
	_biome_noise.noise_type = FastNoiseLite.TYPE_PERLIN
	_biome_noise.frequency = 0.001

	_apply_seed()

func _apply_seed() -> void:
	_terrain_noise.seed = seed
	_cave_noise.seed = seed + 1
	_biome_noise.seed = seed + 2

## Fill a chunk with terrain data based on world position
func fill_chunk(chunk: Chunk, chunk_pos: Vector3i) -> void:
	var chunk_size: int = chunk.chunk_size
	var world_height: int = chunk.world_height
	var sea_level: int = 48

	for x in range(chunk_size):
		for z in range(chunk_size):
			var wx: int = chunk_pos.x * chunk_size + x
			var wz: int = chunk_pos.z * chunk_size + z
			var biome := _get_biome(wx, wz)
			var surface_y := _get_surface_height(wx, wz, biome, sea_level)

			for y in range(world_height):
				var block_id := _get_block_at(wx, y, wz, surface_y, sea_level, biome)
				if block_id != BlockRegistry.BlockID.AIR:
					chunk.set_block(Vector3i(x, y, z), block_id)

func _get_biome(wx: int, wz: int) -> Biome:
	var n: float = _biome_noise.get_noise_2d(float(wx), float(wz))
	if n < -0.3:   return Biome.DESERT
	elif n < 0.0:  return Biome.PLAINS
	elif n < 0.3:  return Biome.FOREST
	else:          return Biome.TUNDRA

func _get_surface_height(wx: int, wz: int, biome: Biome, sea_level: int) -> int:
	var n: float = _terrain_noise.get_noise_2d(float(wx), float(wz))
	var amplitude: float = 30.0
	match biome:
		Biome.DESERT:  amplitude = 15.0
		Biome.FOREST:  amplitude = 35.0
		Biome.TUNDRA:  amplitude = 40.0
	return sea_level + int(n * amplitude)

func _get_block_at(wx: int, y: int, wz: int, surface_y: int, sea_level: int, biome: Biome) -> int:
	var B := BlockRegistry.BlockID

	# Bedrock floor
	if y == 0:
		return B.BEDROCK

	# Cave carving — use 3D noise
	if y > 5 and y < surface_y - 5:
		var cave: float = _cave_noise.get_noise_3d(float(wx), float(y), float(wz))
		if cave > 0.6:
			return B.AIR

	# Underground
	if y < surface_y - 4:
		return B.STONE

	# Sub-surface layer
	if y < surface_y:
		match biome:
			Biome.DESERT: return B.SAND
			_:            return B.DIRT

	# Surface
	if y == surface_y:
		match biome:
			Biome.DESERT: return B.SAND
			Biome.TUNDRA: return B.SNOW
			_:            return B.GRASS

	return B.AIR
