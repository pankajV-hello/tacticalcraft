## VoxelWorld.gd
## World manager — owns all chunks, handles block get/set, coordinates generation
## Attach to: Node3D named "VoxelWorld" in the main game scene
extends Node3D

const CHUNK_SIZE: int = 16
const WORLD_HEIGHT: int = 128
const RENDER_DISTANCE: int = 8  # chunks in each direction

signal chunk_loaded(chunk_pos: Vector3i)
signal block_changed(world_pos: Vector3i, block_id: int)

@export var world_seed: int = 12345
@export var generate_on_ready: bool = true

var chunks: Dictionary = {}          # Vector3i -> Chunk
var chunk_scene: PackedScene
var generator: WorldGenerator
var block_registry: BlockRegistry

func _ready() -> void:
	generator = WorldGenerator.new()
	generator.seed = world_seed
	block_registry = BlockRegistry.new()
	chunk_scene = load("res://assets/scenes/Chunk.tscn")
	if generate_on_ready:
		_generate_initial_world()

## Returns block ID at world position. Returns -1 if chunk not loaded.
func get_block(world_pos: Vector3i) -> int:
	var chunk_pos := _world_to_chunk(world_pos)
	if not chunks.has(chunk_pos):
		return -1
	var local_pos := _world_to_local(world_pos)
	return chunks[chunk_pos].get_block(local_pos)

## Sets block at world position. Triggers mesh rebuild and network sync.
func set_block(world_pos: Vector3i, block_id: int, source_player_id: int = -1) -> void:
	var chunk_pos := _world_to_chunk(world_pos)
	if not chunks.has(chunk_pos):
		push_warning("VoxelWorld: Tried to set block in unloaded chunk %s" % chunk_pos)
		return
	var local_pos := _world_to_local(world_pos)
	chunks[chunk_pos].set_block(local_pos, block_id)
	chunks[chunk_pos].rebuild_mesh()
	_rebuild_adjacent_chunks_if_needed(world_pos)
	block_changed.emit(world_pos, block_id)
	if multiplayer.is_server() and source_player_id != -1:
		_sync_block_to_clients.rpc(world_pos, block_id)

## Load chunks around a player position (called when player moves)
func update_chunks_around(player_world_pos: Vector3) -> void:
	var center_chunk := _world_to_chunk(Vector3i(player_world_pos))
	var chunks_to_load: Array[Vector3i] = []
	for x in range(-RENDER_DISTANCE, RENDER_DISTANCE + 1):
		for z in range(-RENDER_DISTANCE, RENDER_DISTANCE + 1):
			var cp := Vector3i(center_chunk.x + x, 0, center_chunk.z + z)
			if not chunks.has(cp):
				chunks_to_load.append(cp)
	for cp in chunks_to_load:
		await _load_chunk(cp)

func _generate_initial_world() -> void:
	var center := Vector3i.ZERO
	for x in range(-4, 5):
		for z in range(-4, 5):
			await _load_chunk(Vector3i(x, 0, z))

func _load_chunk(chunk_pos: Vector3i) -> void:
	if chunks.has(chunk_pos):
		return
	var chunk: Chunk = chunk_scene.instantiate()
	chunk.position = Vector3(
		chunk_pos.x * CHUNK_SIZE,
		0,
		chunk_pos.z * CHUNK_SIZE
	)
	add_child(chunk)
	chunk.initialise(chunk_pos, CHUNK_SIZE, WORLD_HEIGHT)
	generator.fill_chunk(chunk, chunk_pos)
	chunk.rebuild_mesh()
	chunks[chunk_pos] = chunk
	chunk_loaded.emit(chunk_pos)

func _rebuild_adjacent_chunks_if_needed(world_pos: Vector3i) -> void:
	var local := _world_to_local(world_pos)
	var adjacent_offsets: Array[Vector3i] = []
	if local.x == 0:              adjacent_offsets.append(Vector3i(-1, 0, 0))
	if local.x == CHUNK_SIZE - 1: adjacent_offsets.append(Vector3i(1, 0, 0))
	if local.z == 0:              adjacent_offsets.append(Vector3i(0, 0, -1))
	if local.z == CHUNK_SIZE - 1: adjacent_offsets.append(Vector3i(0, 0, 1))
	var base_chunk := _world_to_chunk(world_pos)
	for offset in adjacent_offsets:
		var neighbor := base_chunk + offset
		if chunks.has(neighbor):
			chunks[neighbor].rebuild_mesh()

func _world_to_chunk(world_pos: Vector3i) -> Vector3i:
	return Vector3i(
		floori(float(world_pos.x) / CHUNK_SIZE),
		0,
		floori(float(world_pos.z) / CHUNK_SIZE)
	)

func _world_to_local(world_pos: Vector3i) -> Vector3i:
	return Vector3i(
		posmod(world_pos.x, CHUNK_SIZE),
		world_pos.y,
		posmod(world_pos.z, CHUNK_SIZE)
	)

@rpc("authority", "call_remote", "reliable")
func _sync_block_to_clients(world_pos: Vector3i, block_id: int) -> void:
	set_block(world_pos, block_id)
