## BlockRegistry.gd
## Central registry of all block types — IDs, properties, materials
## Autoload singleton: add to Project > Autoloads as "BlockRegistry"
extends Node

enum BlockID {
	AIR       = 0,
	GRASS     = 1,
	DIRT      = 2,
	STONE     = 3,
	SAND      = 4,
	SNOW      = 5,
	BEDROCK   = 6,
	WOOD      = 7,
	LEAVES    = 8,
	# Craftable / placeable blocks
	PLANK     = 20,
	COBBLE    = 21,
	BRICK     = 22,
	GLASS     = 23,
	METAL     = 24,   # fortification material
	SANDBAG   = 25,   # player-crafted defence
	BARBED    = 26,   # damages enemies passing through
}

class BlockData:
	var id: int
	var name: String
	var hardness: float    # seconds to break without tools
	var blast_resist: float
	var is_transparent: bool
	var is_placeable: bool  # can players place this?
	var is_walkthrough: bool
	var texture_top: String
	var texture_side: String
	var texture_bottom: String

var _registry: Dictionary = {}  # BlockID -> BlockData

func _ready() -> void:
	_register_all()

func get_block(id: int) -> BlockData:
	return _registry.get(id, _registry[BlockID.AIR])

func is_solid(id: int) -> bool:
	if id == BlockID.AIR: return false
	var data: BlockData = get_block(id)
	return not data.is_walkthrough

func _register_all() -> void:
	_add(BlockID.AIR,     "Air",        0.0,  0.0,  true,  false, true,  "", "", "")
	_add(BlockID.GRASS,   "Grass",      0.8,  0.5,  false, false, false, "grass_top", "grass_side", "dirt")
	_add(BlockID.DIRT,    "Dirt",       0.7,  0.5,  false, false, false, "dirt", "dirt", "dirt")
	_add(BlockID.STONE,   "Stone",      4.0,  6.0,  false, false, false, "stone", "stone", "stone")
	_add(BlockID.SAND,    "Sand",       0.8,  0.5,  false, false, false, "sand", "sand", "sand")
	_add(BlockID.SNOW,    "Snow",       0.5,  0.3,  false, false, false, "snow", "snow", "dirt")
	_add(BlockID.BEDROCK, "Bedrock",    999,  999,  false, false, false, "bedrock", "bedrock", "bedrock")
	_add(BlockID.WOOD,    "Wood",       2.5,  1.5,  false, false, false, "log_top", "log_side", "log_top")
	_add(BlockID.LEAVES,  "Leaves",     0.3,  0.2,  true,  false, false, "leaves", "leaves", "leaves")
	_add(BlockID.PLANK,   "Plank",      2.5,  3.0,  false, true,  false, "plank", "plank", "plank")
	_add(BlockID.COBBLE,  "Cobblestone",4.0,  6.0,  false, true,  false, "cobble", "cobble", "cobble")
	_add(BlockID.BRICK,   "Brick",      5.0,  8.0,  false, true,  false, "brick", "brick", "brick")
	_add(BlockID.GLASS,   "Glass",      0.4,  1.0,  true,  true,  false, "glass", "glass", "glass")
	_add(BlockID.METAL,   "Metal Plate",8.0,  15.0, false, true,  false, "metal", "metal", "metal")
	_add(BlockID.SANDBAG, "Sandbag",    3.0,  12.0, false, true,  false, "sandbag", "sandbag", "sandbag")
	_add(BlockID.BARBED,  "Barbed Wire",1.0,  2.0,  true,  true,  true,  "barbed", "barbed", "barbed")

func _add(id: int, bname: String, hardness: float, blast: float,
		transparent: bool, placeable: bool, walkthrough: bool,
		tex_top: String, tex_side: String, tex_bot: String) -> void:
	var b := BlockData.new()
	b.id = id
	b.name = bname
	b.hardness = hardness
	b.blast_resist = blast
	b.is_transparent = transparent
	b.is_placeable = placeable
	b.is_walkthrough = walkthrough
	b.texture_top = tex_top
	b.texture_side = tex_side
	b.texture_bottom = tex_bot
	_registry[id] = b
