## Player.gd
## FPS CharacterBody3D — handles movement, jump, sprint, gravity
## Children required: Camera3D, BuildController, WeaponManager, PlayerStats
extends CharacterBody3D

signal health_changed(new_health: float, max_health: float)
signal died(player_id: int)

@export var walk_speed: float    = 5.0
@export var sprint_speed: float  = 8.5
@export var jump_velocity: float = 5.5
@export var mouse_sensitivity: float = 0.002
@export var gravity_scale: float = 1.0

@onready var camera: Camera3D           = $Camera3D
@onready var build_ctrl: Node           = $BuildController
@onready var weapon_mgr: Node           = $WeaponManager
@onready var stats: Node                = $PlayerStats
@onready var footstep_player: AudioStreamPlayer3D = $FootstepPlayer
@onready var anim_tree: AnimationTree   = $AnimationTree

var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _is_sprinting: bool = false
var _footstep_timer: float = 0.0
var _is_on_ground_prev: bool = false
var player_id: int = -1  # set by network on join

func _ready() -> void:
	if is_multiplayer_authority():
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		camera.current = true

func _input(event: InputEvent) -> void:
	if not is_multiplayer_authority():
		return
	if event is InputEventMouseMotion:
		_handle_mouse_look(event.relative)
	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority():
		return
	_apply_gravity(delta)
	_handle_jump()
	_handle_movement(delta)
	_handle_footsteps(delta)
	move_and_slide()

func _handle_mouse_look(relative: Vector2) -> void:
	rotate_y(-relative.x * mouse_sensitivity)
	camera.rotate_x(-relative.y * mouse_sensitivity)
	camera.rotation.x = clamp(camera.rotation.x, -1.48, 1.48)

func _apply_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= _gravity * gravity_scale * delta

func _handle_jump() -> void:
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity

func _handle_movement(delta: float) -> void:
	_is_sprinting = Input.is_action_pressed("sprint") and is_on_floor()
	var speed := sprint_speed if _is_sprinting else walk_speed
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if direction:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)

func _handle_footsteps(delta: float) -> void:
	if is_on_floor() and velocity.length_squared() > 1.0:
		var interval := 0.35 if _is_sprinting else 0.55
		_footstep_timer += delta
		if _footstep_timer >= interval:
			_footstep_timer = 0.0
			footstep_player.play()
	else:
		_footstep_timer = 0.0

## Called by network when this player takes damage
@rpc("any_peer", "call_local", "reliable")
func take_damage(amount: float, attacker_id: int) -> void:
	if not is_multiplayer_authority():
		return
	stats.apply_damage(amount)
	health_changed.emit(stats.health, stats.max_health)
	if stats.health <= 0:
		_on_death(attacker_id)

func _on_death(killer_id: int) -> void:
	died.emit(player_id)
	# Respawn handled by GameSession
	set_physics_process(false)
	hide()
