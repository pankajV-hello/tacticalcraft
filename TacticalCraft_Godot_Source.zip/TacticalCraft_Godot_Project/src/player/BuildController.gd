## BuildController.gd
## Handles block placement, breaking, and the build-mode UI
## Parent: Player node | Requires: VoxelWorld autoload, Camera3D sibling
extends Node

signal block_placed(world_pos: Vector3i, block_id: int)
signal block_broken(world_pos: Vector3i)
signal selected_block_changed(block_id: int)

const REACH: float       = 6.0   # metres
const BREAK_TIME: float  = 0.5   # base seconds to break (modified by block hardness)

@export var is_build_mode: bool = false

@onready var camera: Camera3D = $"../Camera3D"
@onready var highlight_mesh: MeshInstance3D = $HighlightCube
@onready var break_progress: ProgressBar    = $"../HUD/BreakProgress"

var _selected_block: int = BlockRegistry.BlockID.PLANK
var _breaking_pos: Vector3i = Vector3i(-9999, -9999, -9999)
var _break_elapsed: float   = 0.0
var _voxel_world: Node       # VoxelWorld autoload ref

func _ready() -> void:
	_voxel_world = get_tree().get_first_node_in_group("voxel_world")
	highlight_mesh.hide()

func _process(delta: float) -> void:
	if not get_parent().is_multiplayer_authority():
		return
	var hit := _raycast()
	_update_highlight(hit)
	if Input.is_action_pressed("break_block") and hit.collided:
		_process_breaking(hit.block_pos, delta)
	else:
		_reset_break()
	if Input.is_action_just_pressed("place_block") and hit.collided and is_build_mode:
		_place_block(hit.normal_pos)

func _raycast() -> Dictionary:
	var space := get_viewport().get_world_3d().direct_space_state
	var origin := camera.global_position
	var direction := -camera.global_transform.basis.z
	var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * REACH)
	query.exclude = [get_parent().get_rid()]
	var result := space.intersect_ray(query)
	if result.is_empty():
		return {collided = false}
	var hit_pos   := Vector3i(result.position - result.normal * 0.5)
	var place_pos := Vector3i(result.position + result.normal * 0.5)
	return {
		collided   = true,
		block_pos  = hit_pos,
		normal_pos = place_pos,
		normal     = result.normal,
	}

func _process_breaking(block_pos: Vector3i, delta: float) -> void:
	if block_pos != _breaking_pos:
		_breaking_pos  = block_pos
		_break_elapsed = 0.0
	var block_id: int = _voxel_world.get_block(block_pos)
	if block_id <= 0:
		return
	var data: BlockRegistry.BlockData = BlockRegistry.get_block(block_id)
	if data.hardness >= 999:
		return  # bedrock — unbreakable
	var time_needed: float = data.hardness * BREAK_TIME
	_break_elapsed += delta
	break_progress.value = (_break_elapsed / time_needed) * 100.0
	break_progress.show()
	if _break_elapsed >= time_needed:
		_voxel_world.set_block.rpc(block_pos, BlockRegistry.BlockID.AIR, multiplayer.get_unique_id())
		block_broken.emit(block_pos)
		_reset_break()

func _place_block(pos: Vector3i) -> void:
	var overlap := _check_player_overlap(pos)
	if overlap:
		return
	_voxel_world.set_block.rpc(pos, _selected_block, multiplayer.get_unique_id())
	block_placed.emit(pos, _selected_block)

func _check_player_overlap(pos: Vector3i) -> bool:
	# Prevent placing a block inside the player's bounding box
	var player_pos := Vector3i(get_parent().global_position)
	return pos == player_pos or pos == player_pos + Vector3i(0, 1, 0)

func _update_highlight(hit: Dictionary) -> void:
	if hit.collided:
		highlight_mesh.global_position = Vector3(hit.block_pos) + Vector3(0.5, 0.5, 0.5)
		highlight_mesh.show()
	else:
		highlight_mesh.hide()

func _reset_break() -> void:
	_breaking_pos  = Vector3i(-9999, -9999, -9999)
	_break_elapsed = 0.0
	break_progress.value = 0
	break_progress.hide()

func set_selected_block(block_id: int) -> void:
	_selected_block = block_id
	selected_block_changed.emit(block_id)
