const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  PageBreak, PageNumber, LevelFormat, VerticalAlign
} = require("docx");
const fs = require("fs");

const BRAND_PURPLE = "3C3489";
const BRAND_TEAL   = "0F6E56";
const BRAND_AMBER  = "854F0B";
const BRAND_DARK   = "1A1A2E";
const LIGHT_PURPLE = "EEEDFE";
const LIGHT_TEAL   = "E1F5EE";
const LIGHT_AMBER  = "FAEEDA";
const LIGHT_GRAY   = "F5F5F5";
const MED_GRAY     = "D3D1C7";
const W = 9360; // content width in DXA

const border = { style: BorderStyle.SINGLE, size: 1, color: "D3D1C7" };
const borders = { top: border, bottom: border, left: border, right: border };
const noBorder = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 400, after: 160 },
    children: [new TextRun({ text, font: "Arial", size: 32, bold: true, color: BRAND_DARK })]
  });
}
function h2(text, color = BRAND_PURPLE) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color, space: 4 } },
    children: [new TextRun({ text, font: "Arial", size: 26, bold: true, color })]
  });
}
function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 80 },
    children: [new TextRun({ text, font: "Arial", size: 22, bold: true, color: BRAND_DARK })]
  });
}
function body(text, opts = {}) {
  return new Paragraph({
    spacing: { before: 80, after: 80 },
    children: [new TextRun({ text, font: "Arial", size: 22, color: "333333", ...opts })]
  });
}
function bullet(text, bold_prefix = "") {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { before: 40, after: 40 },
    children: [
      ...(bold_prefix ? [new TextRun({ text: bold_prefix + " ", font: "Arial", size: 22, bold: true, color: BRAND_DARK })] : []),
      new TextRun({ text, font: "Arial", size: 22, color: "333333" })
    ]
  });
}
function pageBreak() {
  return new Paragraph({ children: [new PageBreak()] });
}
function spacer(n = 1) {
  return new Paragraph({ spacing: { before: n * 120, after: 0 }, children: [new TextRun("")] });
}
function callout(text, fill = LIGHT_PURPLE, textColor = BRAND_PURPLE) {
  return new Table({
    width: { size: W, type: WidthType.DXA },
    columnWidths: [W],
    rows: [new TableRow({ children: [new TableCell({
      borders: noBorders,
      width: { size: W, type: WidthType.DXA },
      shading: { fill, type: ShadingType.CLEAR },
      margins: { top: 160, bottom: 160, left: 240, right: 240 },
      children: [new Paragraph({ children: [new TextRun({ text, font: "Arial", size: 22, color: textColor, bold: true })] })]
    })] })]
  });
}
function twoColTable(rows, headers, col1 = 3000, col2 = 6360) {
  const headerRow = new TableRow({
    children: [
      new TableCell({ borders, shading: { fill: BRAND_PURPLE, type: ShadingType.CLEAR }, width: { size: col1, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: headers[0], font: "Arial", size: 20, bold: true, color: "FFFFFF" })] })] }),
      new TableCell({ borders, shading: { fill: BRAND_PURPLE, type: ShadingType.CLEAR }, width: { size: col2, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: headers[1], font: "Arial", size: 20, bold: true, color: "FFFFFF" })] })] }),
    ]
  });
  const dataRows = rows.map(([c1, c2], i) => new TableRow({
    children: [
      new TableCell({ borders, shading: { fill: i % 2 === 0 ? "FFFFFF" : LIGHT_GRAY, type: ShadingType.CLEAR }, width: { size: col1, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: c1, font: "Arial", size: 20, bold: true, color: BRAND_DARK })] })] }),
      new TableCell({ borders, shading: { fill: i % 2 === 0 ? "FFFFFF" : LIGHT_GRAY, type: ShadingType.CLEAR }, width: { size: col2, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: c2, font: "Arial", size: 20, color: "444444" })] })] }),
    ]
  }));
  return new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [col1, col2], rows: [headerRow, ...dataRows] });
}
function threeColTable(rows, headers) {
  const cw = [2200, 3580, 3580];
  const headerRow = new TableRow({
    children: headers.map((h, i) => new TableCell({ borders, shading: { fill: BRAND_TEAL, type: ShadingType.CLEAR }, width: { size: cw[i], type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: h, font: "Arial", size: 20, bold: true, color: "FFFFFF" })] })] }))
  });
  const dataRows = rows.map(([c1, c2, c3], i) => new TableRow({
    children: [c1, c2, c3].map((c, j) => new TableCell({ borders, shading: { fill: i % 2 === 0 ? "FFFFFF" : LIGHT_TEAL, type: ShadingType.CLEAR }, width: { size: cw[j], type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: c, font: "Arial", size: 20, color: j === 0 ? BRAND_DARK : "444444", bold: j === 0 })] })] }))
  }));
  return new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: cw, rows: [headerRow, ...dataRows] });
}

// ─── COVER PAGE ────────────────────────────────────────────────────────────
const cover = [
  spacer(4),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 80 }, children: [new TextRun({ text: "TACTICALCRAFT", font: "Arial", size: 72, bold: true, color: BRAND_PURPLE })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 200 }, children: [new TextRun({ text: "Build. Fortify. Destroy.", font: "Arial", size: 36, color: BRAND_TEAL, italics: true })] }),
  new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [W], rows: [new TableRow({ children: [new TableCell({ borders: noBorders, shading: { fill: BRAND_PURPLE, type: ShadingType.CLEAR }, margins: { top: 240, bottom: 240, left: 480, right: 480 }, width: { size: W, type: WidthType.DXA }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "FOUNDER STRATEGY & TECHNICAL DESIGN DOCUMENT", font: "Arial", size: 24, bold: true, color: "FFFFFF" })] })] })] })] }),
  spacer(2),
  new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [4680, 4680], rows: [
    new TableRow({ children: [
      new TableCell({ borders: noBorders, width: { size: 4680, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 0, right: 120 }, children: [
        new Paragraph({ children: [new TextRun({ text: "Founder", font: "Arial", size: 18, color: "888888" })] }),
        new Paragraph({ children: [new TextRun({ text: "Pankaj Verma", font: "Arial", size: 22, bold: true, color: BRAND_DARK })] }),
        spacer(),
        new Paragraph({ children: [new TextRun({ text: "Studio", font: "Arial", size: 18, color: "888888" })] }),
        new Paragraph({ children: [new TextRun({ text: "TacticalCraft Games Pty Ltd", font: "Arial", size: 22, bold: true, color: BRAND_DARK })] }),
      ]}),
      new TableCell({ borders: noBorders, width: { size: 4680, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 0 }, children: [
        new Paragraph({ children: [new TextRun({ text: "Location", font: "Arial", size: 18, color: "888888" })] }),
        new Paragraph({ children: [new TextRun({ text: "Melbourne, VIC, Australia", font: "Arial", size: 22, bold: true, color: BRAND_DARK })] }),
        spacer(),
        new Paragraph({ children: [new TextRun({ text: "Version", font: "Arial", size: 18, color: "888888" })] }),
        new Paragraph({ children: [new TextRun({ text: "v1.0 — May 2026", font: "Arial", size: 22, bold: true, color: BRAND_DARK })] }),
      ]}),
    ]}),
  ]}),
  pageBreak(),
];

// ─── SECTION 1: STRATEGY ───────────────────────────────────────────────────
const strategy = [
  h1("1. Strategy"),
  h2("1.1 Vision & Mission", BRAND_PURPLE),
  callout("Vision: Become the world's leading hybrid sandbox-tactical game — where every player is both architect and warrior.", LIGHT_PURPLE, BRAND_PURPLE),
  spacer(),
  callout("Mission: Build a deeply creative, tactically rich multiplayer world that rewards both builders and fighters equally, with no pay-to-win mechanics.", LIGHT_TEAL, BRAND_TEAL),
  spacer(),
  h2("1.2 Market Position", BRAND_PURPLE),
  body("TacticalCraft sits in a white space between two dominant categories. No current game delivers true military-grade FPS gunplay inside a deep voxel construction system at the same time."),
  spacer(),
  threeColTable([
    ["Fortnite", "Building + battle royale", "Arcade building, not voxel — no base ownership or persistence"],
    ["Minecraft", "Voxel sandbox", "No real FPS combat — combat is primitive"],
    ["7 Days to Die", "Survival + enemy waves", "Dated graphics, weak gunplay, small player base"],
    ["Hytale", "Sandbox narrative", "No tactical FPS — building + adventure only"],
    ["TacticalCraft", "Voxel sandbox + tactical FPS", "The only game doing both properly — our position"],
  ], ["Game", "Strengths", "Gap we fill"]),
  spacer(),
  h2("1.3 Strategic Pillars", BRAND_PURPLE),
  h3("Pillar 1 — Creator Economy"),
  bullet("Players own their builds; bases persist across sessions and seasons"),
  bullet("Community-voted maps enter the official rotation — creators earn in-game rewards"),
  bullet("Modding tools open in Phase 3, expanding content without dev cost"),
  spacer(),
  h3("Pillar 2 — Deep Tactical Combat"),
  bullet("Class system (Builder, Soldier, Engineer, Medic, Sniper, Demolisher) creates team interdependence"),
  bullet("Destructible terrain changes every firefight — no two encounters are identical"),
  bullet("Seasonal clan wars with territory control create long-term competitive stakes"),
  spacer(),
  h3("Pillar 3 — Live Service + Community"),
  bullet("90-day season cadence: new map, new event, new Battle Pass per season"),
  bullet("AI-driven world events (invasions, weather, resource shifts) every 2 weeks"),
  bullet("Community-first: Discord-driven feedback loops directly shape content priorities"),
  spacer(),
  h2("1.4 Competitive Moat", BRAND_PURPLE),
  twoColTable([
    ["Voxel + FPS quality", "Both systems built to AAA standard — not a compromise of either"],
    ["Persistent worlds", "Your base survives between sessions — investment and attachment build over time"],
    ["Clan territory wars", "Multi-week competitive seasons create communities, not just players"],
    ["AI world events", "Unpredictable Claude-powered events force cooperation and create content"],
    ["Streamer-native design", "Spectacular base raids, dramatic collapses — built to be watched and shared"],
    ["No pay-to-win", "Cosmetics only — trust and retention driver in a market burned by P2W"],
  ], ["Moat", "Why it's hard to copy"]),
  spacer(),
  h2("1.5 Success Metrics — Year 1", BRAND_PURPLE),
  threeColTable([
    ["Month 4",  "Alpha ready",           "Internal + 100 Discord beta testers"],
    ["Month 6",  "Kickstarter live",      "$50K AUD target, 2,000+ Steam wishlists"],
    ["Month 8",  "Steam Early Access",    "5,000 units, 4.0+ Steam rating"],
    ["Month 10", "10K registered players","Screen Australia grant approved"],
    ["Month 12", "Full 1.0 launch",       "25K players, $150K+ revenue, Series A ready"],
  ], ["Milestone", "Goal", "Success indicator"]),
  pageBreak(),
];

// ─── SECTION 2: APPROACH ───────────────────────────────────────────────────
const approach = [
  h1("2. Product Approach"),
  h2("2.1 Development Philosophy", BRAND_TEAL),
  callout("Principle: Ship a small, excellent core loop before expanding scope. One great map with brilliant gunplay beats ten mediocre maps.", LIGHT_TEAL, BRAND_TEAL),
  spacer(),
  h3("Founder-Led Phase (Months 1–7)"),
  bullet("You are Game Director, Product Manager, and Community Lead simultaneously"),
  bullet("Hire narrow, skilled freelancers for execution (Godot dev, 3D artist, sound designer)"),
  bullet("Weekly dev logs on Discord keep community engaged and accountable to milestones"),
  bullet("Every major decision posted to Discord for community vote — creates ownership"),
  spacer(),
  h3("Iterative Alpha Loop"),
  bullet("Build the minimum playable slice: voxel world + FPS movement + 2 players"),
  bullet("Playtest with 8 people within month 3. Break it. Fix it. Playtest again."),
  bullet("Collect metrics from day 1: session length, block placement rates, deaths per minute"),
  bullet("Use data to decide what to build next — not assumptions"),
  spacer(),
  h2("2.2 Build Phases", BRAND_TEAL),
  twoColTable([
    ["Phase 1 (M1–7)",   "Core loop prototype — voxel world, FPS movement, 2 classes, basic multiplayer, Kickstarter"],
    ["Phase 2 (M7–12)",  "Early Access — 4 classes, 2 maps, clan system, Season 1 Battle Pass, cosmetic shop"],
    ["Phase 3 (Y2)",     "Full launch — 6 classes, 4 maps, mobile companion, console port planning, modding tools"],
    ["Phase 4 (Y3+)",    "Platform expansion — user-generated content marketplace, esports clan league, publisher deal or IPO"],
  ], ["Phase", "Scope"]),
  spacer(),
  h2("2.3 Quality Standards", BRAND_TEAL),
  bullet("Every feature must pass a 60-second onboarding test: can a new player understand it without a tutorial?"),
  bullet("Steam rating target: 4.0+ from day 1. Below 3.5 = full stop and fix before continuing"),
  bullet("Latency SLA: 60ms average, 120ms maximum for all multiplayer actions"),
  bullet("Zero pay-to-win mechanics — ever. This is a core promise, not a guideline"),
  pageBreak(),
];

// ─── SECTION 3: BRANDING ───────────────────────────────────────────────────
const branding = [
  h1("3. Branding"),
  h2("3.1 Brand Foundation", BRAND_AMBER),
  twoColTable([
    ["Name",        "TacticalCraft"],
    ["Domain",      "tacticalcraft.games (primary) | tactical-craft.com (redirect)"],
    ["Tagline",     "Build. Fortify. Destroy."],
    ["Category",    "Sandbox Tactical FPS"],
    ["Audience",    "16–34, PC-first gamers who love both Minecraft and FPS titles"],
    ["Personality", "Intense, creative, community-driven, never pay-to-win, never corporate"],
  ], ["Element", "Definition"]),
  spacer(),
  h2("3.2 Visual Identity", BRAND_AMBER),
  h3("Colour Palette"),
  twoColTable([
    ["Combat Purple #3C3489",  "Primary brand — tactical, intense, distinctive. Used in logo, CTA buttons"],
    ["Forge Teal #0F6E56",     "Secondary — nature, building, growth. World and terrain elements"],
    ["Ember Amber #854F0B",    "Accent — danger, fire, explosions, season highlights"],
    ["Midnight #1A1A2E",       "Background — dark mode UI, night maps, premium feel"],
    ["Bone White #F5F4EF",     "Light surfaces — text backgrounds, card UI"],
  ], ["Colour", "Usage"]),
  spacer(),
  h3("Typography"),
  bullet("Display / logo: Rajdhani Bold or Barlow Condensed Black — military-adjacent, clean"),
  bullet("UI headings: Inter SemiBold — crisp, readable at all sizes"),
  bullet("Body / HUD: Inter Regular — universal, high legibility"),
  bullet("Monospace / code / coords: JetBrains Mono — used in build menus, server stats"),
  spacer(),
  h3("Logo System"),
  bullet("Mark: Stylised voxel cube with a crosshair integrated into the geometry"),
  bullet("Wordmark: TACTICALCRAFT in Barlow Condensed Black — all caps, tracked wide"),
  bullet("Lockup: Mark left, wordmark right — horizontal for headers, stacked for icons"),
  bullet("Minimum size: 24px for mark, 120px for wordmark — never below these"),
  spacer(),
  h2("3.3 Tone of Voice", BRAND_AMBER),
  callout("Speak like a squad leader, not a marketing department. Direct. Confident. A little irreverent. Always real.", LIGHT_AMBER, BRAND_AMBER),
  spacer(),
  twoColTable([
    ["Direct",         "We say what we mean. No corporate fluff. No vague promises."],
    ["Confident",      "We know what game we're building. We don't hedge."],
    ["Irreverent",     "We can laugh. We're not afraid of memes. Gaming culture is our culture."],
    ["Community-first","Players are co-creators. We talk with them, not at them."],
    ["Honest",         "When something breaks, we say so. When we change direction, we explain why."],
  ], ["Trait", "In practice"]),
  spacer(),
  h3("Do / Don't"),
  twoColTable([
    ["'Your base. Your rules. Their ruin.'",   "'Experience the ultimate gaming adventure!'"],
    ["'Season 2 drops Tuesday. New map. New chaos.'", "'We are excited to announce...'"],
    ["'We broke the clan war system. It's fixed.'", "Ignoring bugs in patch notes"],
    ["'Community voted: Tundra map wins. We're building it.'", "Pretending all decisions are unilateral"],
  ], ["Do say this", "Not this"]),
  pageBreak(),
];

// ─── SECTION 4: SOCIAL MEDIA ───────────────────────────────────────────────
const social = [
  h1("4. Social Media & Community Strategy"),
  h2("4.1 Channel Strategy", BRAND_PURPLE),
  threeColTable([
    ["Discord",    "Primary community hub",          "Dev logs, beta access, clan boards, polls, bug reports. Start immediately. Target: 1K members before Kickstarter"],
    ["Reddit",     "r/TacticalCraft + r/indiegaming", "Gameplay clips, dev updates, AMA sessions. Organic reach. Avoid paid promotion."],
    ["TikTok/Reels", "Viral short-form clips",       "15–30 sec clips: spectacular base raids, funny moments, building timelapses. Post 3x/week minimum"],
    ["YouTube",    "Long-form content + trailers",   "Dev vlogs, patch notes deep-dives, base tour features. 1x/week. Trailers for all major milestones"],
    ["X (Twitter)", "Fast news + developer voice",   "Patch announcements, quick takes, reply to gaming discourse. Founder account — Pankaj's voice, not brand account"],
    ["Steam",      "News + community hub",           "Patch notes, announcements, community art. Feeds directly to people who wishlisted. Critical channel"],
  ], ["Platform", "Role", "Approach"]),
  spacer(),
  h2("4.2 Content Pillars", BRAND_PURPLE),
  h3("Pillar 1 — Build Porn (40% of content)"),
  body("The most viral gaming content on all platforms. Time-lapses of incredible bases. Community build showcases. 'Rate this base' posts. Speed build challenges. This content requires zero marketing budget — it creates itself."),
  spacer(),
  h3("Pillar 2 — Chaos Moments (30% of content)"),
  body("Explosive base raids caught on clip. Clutch last-stand moments. AI invasion events. Unexpected building collapses during firefights. These are the moments people share. Design the game so they happen constantly."),
  spacer(),
  h3("Pillar 3 — Behind the Build (20% of content)"),
  body("Weekly dev log on Discord and YouTube. What we built this week. What broke. What the community asked for and why we did or didn't do it. This builds parasocial investment and trust that converts into Kickstarter backers."),
  spacer(),
  h3("Pillar 4 — Community Spotlight (10% of content)"),
  body("Feature community builds, best clips of the week, top clan war moments. Players who get featured become brand advocates. Cost: zero."),
  spacer(),
  h2("4.3 Pre-Launch Community Funnel", BRAND_PURPLE),
  twoColTable([
    ["Month 1–2:  Awareness",    "Post concept art + game design docs on Reddit. Start Discord. No game yet — sell the vision."],
    ["Month 3–4:  Interest",     "First gameplay GIFs. Block physics. Early build footage. Weekly Discord updates."],
    ["Month 5:    Alpha tease",  "Closed beta invite to top 100 Discord members. They post footage. Organic reach."],
    ["Month 6:    Kickstarter",  "60-second gameplay trailer. Steam wishlist push. Press outreach. All channels fire simultaneously."],
    ["Month 7+:   Retention",    "Regular content cadence. Community events. Streamer partnerships. Never go quiet."],
  ], ["Phase", "Activity"]),
  spacer(),
  h2("4.4 Streamer & Creator Strategy", BRAND_PURPLE),
  callout("Rule: 10 streamers with 20K–200K subscribers are worth more than 1 streamer with 2M. Niche gaming communities convert.", LIGHT_PURPLE, BRAND_PURPLE),
  spacer(),
  bullet("Target tier 1: Minecraft YouTubers who also play FPS games — perfect audience overlap"),
  bullet("Target tier 2: Survival game streamers (7 Days to Die, Valheim, DayZ communities)"),
  bullet("Target tier 3: Strategy builders — Factorio, Satisfactory, Dyson Sphere audience"),
  bullet("Outreach: Personal DM from Pankaj. Not a PR email. Reference their content specifically."),
  bullet("Offer: Early alpha access + in-game streamer cosmetic pack — no payment initially"),
  bullet("Phase 2: Revenue-share program for creators who consistently drive installs"),
  pageBreak(),
];

// ─── SECTION 5: TECHNICAL DESIGN ───────────────────────────────────────────
const techDesign = [
  h1("5. Technical Design"),
  h2("5.1 Core Systems Architecture", BRAND_TEAL),
  threeColTable([
    ["Voxel Engine",    "Godot 4 + zylann/godot_voxel", "Chunked 16x16x16 voxels, LOD, greedy meshing"],
    ["FPS Combat",      "Custom GDScript + PhysicsServer3D", "Hitscan + projectile hybrid, per-bone hit detection"],
    ["Multiplayer",     "Godot ENet + Nakama backend", "Authoritative server, client prediction, lag comp"],
    ["World Gen",       "FastNoiseLite layered noise", "Biomes, caves, surface features, deterministic seed"],
    ["AI Enemies",      "NavigationAgent3D + custom BT", "Behaviour trees for enemy AI, wave manager"],
    ["Events",          "Claude API (claude-sonnet-4)", "Procedural world event generation and narration"],
    ["Auth & Accounts", "Nakama email + Steam SSO", "JWT sessions, 30-day refresh tokens"],
    ["Payments",        "Stripe SDK + Steam Wallet", "Season pass, cosmetic shop, one-time purchase"],
  ], ["System", "Technology", "Notes"]),
  spacer(),
  h2("5.2 Voxel System Design", BRAND_TEAL),
  h3("Chunk Architecture"),
  bullet("World divided into 16x16x128 vertical columns (XZ chunks, full world height per chunk)"),
  bullet("Each chunk stores block IDs as a flat Uint8Array — memory-efficient, fast access"),
  bullet("Greedy meshing: adjacent same-block faces merged into single quads — 10x render performance"),
  bullet("LOD system: chunks >4 away from player render at half resolution"),
  bullet("Chunk loading: async in background thread, never blocking main game loop"),
  spacer(),
  h3("Block Registry"),
  bullet("Enum-based block IDs — never raw integers in game logic"),
  bullet("Per-block properties: hardness, blast resistance, transparency, walkthrough"),
  bullet("Craftable blocks (Plank, Cobble, Brick, Metal, Sandbag, Barbed Wire) form the tactical meta"),
  bullet("Destruction physics: explosive damage radius applies to blast resistance ratings"),
  spacer(),
  h2("5.3 Multiplayer Architecture", BRAND_TEAL),
  callout("Server-authoritative model: the server owns all game state. Clients predict locally and reconcile on server confirmation.", LIGHT_TEAL, BRAND_TEAL),
  spacer(),
  h3("Network Topology"),
  bullet("Dedicated game servers (Hetzner AX41, Sydney region) — one per match"),
  bullet("Max 32 players per server — tested ceiling before degraded performance"),
  bullet("Player position sync: 20Hz state broadcast, client interpolation between packets"),
  bullet("Block changes: reliable RPC to all clients in chunk proximity — not broadcast to all"),
  bullet("Nakama WebSocket: match state, presence events, chat, clan data"),
  spacer(),
  h3("Lag Compensation"),
  bullet("Client-side prediction for movement — feel immediate, reconcile on server tick"),
  bullet("Hit registration lag compensation: server rewinds player positions by client latency"),
  bullet("Block placement: optimistic local placement with server validation — revert if rejected"),
  spacer(),
  h2("5.4 Database Design", BRAND_TEAL),
  threeColTable([
    ["players",    "id, username, email, steam_id, created_at, last_login", "Nakama managed — PostgreSQL"],
    ["player_stats","player_id, kills, deaths, blocks_placed, playtime_secs","Game stats aggregate"],
    ["matches",    "id, map_id, started_at, ended_at, winner_clan_id", "Match history"],
    ["clans",      "id, name, tag, leader_id, member_count, territory_points", "Clan registry"],
    ["inventory",  "player_id, item_id, quantity, acquired_at", "Cosmetics + items"],
    ["seasons",    "id, number, start_date, end_date, battle_pass_id", "Season metadata"],
    ["purchases",  "id, player_id, item_id, stripe_charge_id, amount, currency", "Transaction log"],
  ], ["Table", "Key columns", "Notes"]),
  spacer(),
  h2("5.5 AI Integration — Claude API", BRAND_TEAL),
  body("TacticalCraft uses the Claude API (claude-sonnet-4-20250514) to generate dynamic world events, NPC dialogue, and seasonal story content. This creates a living world that never repeats."),
  spacer(),
  bullet("World events: Every 14 days, Claude generates a new invasion event — enemy faction, backstory, objectives, special drops"),
  bullet("Event narration: 3–5 sentences of in-game lore text delivered via HUD broadcast"),
  bullet("NPC merchants: Procedural dialogue lines based on current season + world state"),
  bullet("Cost estimate: ~$0.003 per event generation — negligible at scale"),
  spacer(),
  h2("5.6 Infrastructure", BRAND_TEAL),
  twoColTable([
    ["Dev / CI",          "GitHub Actions — automated GDScript linting + Godot headless export test on every PR"],
    ["Game servers",      "Hetzner AX41 (4-core, 64GB, Sydney) — $80 AUD/month per active server"],
    ["Nakama",            "Self-hosted on Hetzner CX21 (2-core, 4GB) — $15 AUD/month"],
    ["Database",          "PostgreSQL 16 on same Nakama host (small scale) → migrate to managed RDS at 10K players"],
    ["CDN",               "Cloudflare — static assets, website, DDoS protection — free tier"],
    ["Monitoring",        "Grafana + Prometheus for server metrics, Sentry for error tracking"],
    ["Backups",           "Daily PostgreSQL dumps to Hetzner StorageBox — $5 AUD/month"],
    ["Steam",             "$100 USD one-time Steamworks fee — recoverable at $1K revenue"],
  ], ["Component", "Solution & cost"]),
  pageBreak(),
];

// ─── SECTION 6: CLAUDE CODE GUIDE ──────────────────────────────────────────
const claudeCode = [
  h1("6. Building with Claude Code"),
  h2("6.1 What is Claude Code?", BRAND_PURPLE),
  body("Claude Code is Anthropic's agentic CLI coding tool. Run 'claude' in your project terminal and it reads the codebase, writes code, runs tests, and iterates — all autonomously guided by CLAUDE.md."),
  spacer(),
  callout("Install: npm install -g @anthropic-ai/claude-code | Run: cd tacticalcraft && claude", LIGHT_PURPLE, BRAND_PURPLE),
  spacer(),
  h2("6.2 How to Use Claude Code for TacticalCraft", BRAND_PURPLE),
  twoColTable([
    ["Start a session",       "cd /path/to/tacticalcraft && claude — it auto-reads CLAUDE.md"],
    ["Build next feature",    "Tell it: 'Implement the WaveManager — spawn 3 enemy types in waves of increasing size'"],
    ["Fix a bug",             "Paste the error. Say: 'Fix this. Don't change unrelated files.'"],
    ["Add a weapon",          "'Create SniperRifle.gd extending BaseWeapon — bolt-action, 1 shot, 150 damage, 4 sec reload'"],
    ["Write tests",           "'Write GUT test cases for VoxelWorld.get_block and set_block edge cases'"],
    ["Refactor",              "'The BuildController is too long. Extract hit detection to its own class.'"],
  ], ["Task", "How to prompt"]),
  spacer(),
  h2("6.3 Effective Prompting for Game Dev", BRAND_PURPLE),
  bullet("Be specific about the Godot node type: 'extends CharacterBody3D' not 'a player script'"),
  bullet("Specify signals: 'emit a signal when the block breaks — other systems listen to it'"),
  bullet("Reference existing code: 'follow the same pattern as BuildController.gd'"),
  bullet("Set constraints: 'max 40 lines per function, typed variables only, no C#'"),
  bullet("Iterate fast: 'good, now add a reload animation hook' — don't rewrite whole prompts"),
  spacer(),
  callout("Tip: Keep CLAUDE.md updated. Every new system you add, document it there. Claude Code reads it fresh every session.", LIGHT_AMBER, BRAND_AMBER),
  pageBreak(),
];

// ─── ASSEMBLE ───────────────────────────────────────────────────────────────
const doc = new Document({
  numbering: {
    config: [{
      reference: "bullets",
      levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 480, hanging: 240 } } } }]
    }]
  },
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, font: "Arial", color: BRAND_DARK }, paragraph: { spacing: { before: 400, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, font: "Arial" }, paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 22, bold: true, font: "Arial" }, paragraph: { spacing: { before: 200, after: 80 }, outlineLevel: 2 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    headers: {
      default: new Header({
        children: [new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [6000, 3360], rows: [new TableRow({ children: [
          new TableCell({ borders: noBorders, width: { size: 6000, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: "TACTICALCRAFT — Founder Strategy & Technical Design", font: "Arial", size: 18, color: BRAND_PURPLE, bold: true })] })] }),
          new TableCell({ borders: noBorders, width: { size: 3360, type: WidthType.DXA }, children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "CONFIDENTIAL — v1.0  May 2026", font: "Arial", size: 16, color: "999999" })] })] }),
        ]})] })]
      })
    },
    children: [
      ...cover,
      ...strategy,
      ...approach,
      ...branding,
      ...social,
      ...techDesign,
      ...claudeCode,
      // Final page
      spacer(2),
      callout("This document is a living artefact. Update it every sprint. It is the single source of truth for TacticalCraft.", LIGHT_PURPLE, BRAND_PURPLE),
    ]
  }]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/mnt/user-data/outputs/TacticalCraft_Strategy_Technical_Document.docx", buf);
  console.log("Document written successfully.");
});
